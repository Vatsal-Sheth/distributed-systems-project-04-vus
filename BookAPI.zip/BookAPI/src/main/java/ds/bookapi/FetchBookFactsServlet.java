/**@author Vatsal Sheth
 * vus
 */
package ds.bookapi;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * Servlet for fetching detailed book facts from the Open Library API.
 *
 * This servlet handles GET requests to retrieve specific book information 
 * based on a unique work identifier, logs the request and response, 
 * and returns book details as JSON.
 */
@WebServlet("/fetchBookFacts")
public class FetchBookFactsServlet extends HttpServlet {

    /**
     * Logger for recording service interactions and metrics.
     */
    private MongoLogger mongoLogger;

    /**
     * Formatter for creating structured log entries.
     */
    private MongoLogFormatter mongoLogFormatter;

    /**
     * Initializes the servlet by creating MongoLogger and MongoLogFormatter instances.
     *
     * This method is called by the servlet container when the servlet is first loaded.
     *
     * @throws ServletException if an error occurs during initialization
     */
    @Override
    public void init() throws ServletException {
        mongoLogger = new MongoLogger(); // Create MongoLogger instance
        mongoLogFormatter = new MongoLogFormatter(mongoLogger); // Pass MongoLogger to MongoLogFormatter
    }

    /**
     * Handles GET requests to retrieve detailed book information.
     *
     * Processes the work identifier parameter, calls the Open Library API, 
     * and returns detailed book facts. Logs request and response details.
     *
     * @param req the HttpServletRequest object containing the book work identifier
     * @param resp the HttpServletResponse object for sending the book details
     * @throws IOException if an I/O error occurs during request processing
     */
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        // Extract the work identifier
        String workId = req.getParameter("workId");

        // Log the incoming request with device details
        mongoLogFormatter.logRequest(workId, req.getHeader("Device-Model"), req.getHeader("OS-Version"));

        // Construct Open Library API URL for specific book details
        String apiUrl = "https://openlibrary.org" + workId + ".json";
        try {
            // Open connection to Open Library API
            HttpURLConnection connection = (HttpURLConnection) new URL(apiUrl).openConnection();
            connection.setRequestMethod("GET");

            // Read API response
            BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            StringBuilder response = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                response.append(line);
            }

            // Log the API response
            mongoLogFormatter.logResponse(response.toString());

            // Send response back to client
            resp.setContentType("application/json");
            PrintWriter writer = resp.getWriter();
            writer.write(response.toString());
        } catch (Exception e) {
            // Handle any errors during API call
            e.printStackTrace();
            resp.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Failed to fetch book facts");
        }
    }
}