/**@author Vatsal Sheth
 * vus
 */
package ds.bookapi;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Servlet for handling the dashboard functionality in the Book API application.
 *
 * This servlet retrieves and processes various metrics and logs from MongoDB,
 * including recent logs, total request count, average latency, and top queries.
 */
public class DashboardServlet extends HttpServlet {

    /**
     * The MongoLogger instance used to interact with MongoDB for logging and metrics.
     */
    private MongoLogger mongoLogger;

    /**
     * Initializes the servlet by creating a new MongoLogger instance.
     *
     * @throws ServletException if there is an error during initialization
     */
    @Override
    public void init() throws ServletException {
        mongoLogger = new MongoLogger(); // Initialize MongoLogger
    }

    /**
     * Handles GET requests to the dashboard.
     *
     * Retrieves logs, total request count, average latency, and top queries,
     * then forwards the data to the dashboard view.
     *
     * @param req the HttpServletRequest object
     * @param resp the HttpServletResponse object
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // Fetch logs
        List<String> logs = mongoLogger.getLatestLogs(100);

        // Calculate total requests
        int totalRequests = mongoLogger.getTotalRequestCount();

        // Calculate average latency
        double avgLatency = mongoLogger.getAverageLatency();

        // Get top 5 queries
        Map<String, Integer> topQueries = mongoLogger.getTopQueries(5);

        // Set attributes for JSP
        req.setAttribute("logs", logs);
        req.setAttribute("totalRequests", totalRequests);
        req.setAttribute("avgLatency", avgLatency);
        req.setAttribute("topQueries", topQueries);

        // Forward to JSP
        req.getRequestDispatcher("/WEB-INF/views/dashboard.jsp").forward(req, resp);
    }

    /**
     * Closes the MongoDB connection when the servlet is being destroyed.
     */
    @Override
    public void destroy() {
        mongoLogger.close(); // Close MongoDB connection
    }
}