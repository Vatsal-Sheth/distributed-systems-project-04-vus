/**@author Vatsal Sheth
 * vus
 */
package ds.bookapi;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * Provides formatted logging functionality for book service requests and responses.
 *
 * This class wraps the MongoLogger to create structured, consistent log entries
 * with standardized formatting and timestamp handling.
 */
public class MongoLogFormatter {

    /**
     * The MongoLogger instance used for persisting log entries.
     */
    private final MongoLogger mongoLogger;

    /**
     * Formatter for creating consistent timestamp strings.
     *
     * Formats timestamps as "yyyy-MM-dd HH:mm:ss.SSS" (e.g., "2024-12-15 14:30:45.123")
     */
    private static final DateTimeFormatter TIMESTAMP_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS");

    /**
     * Constructs a new MongoLogFormatter with the specified MongoLogger.
     *
     * @param mongoLogger The MongoLogger instance to use for logging
     */
    public MongoLogFormatter(MongoLogger mongoLogger) {
        this.mongoLogger = mongoLogger;
    }

    /**
     * Logs an incoming request with device and query details.
     *
     * Creates a formatted log entry for an incoming request, capturing
     * the query, device model, and operating system version.
     *
     * @param query The search or API query received
     * @param deviceModel The model of the device making the request
     * @param osVersion The operating system version of the device
     */
    public void logRequest(String query, String deviceModel, String osVersion) {
        String timestamp = LocalDateTime.now().format(TIMESTAMP_FORMATTER);
        String formattedLog = formatLogEntry("Request received", query, deviceModel, osVersion, timestamp);
        mongoLogger.log(formattedLog, query, null, deviceModel, osVersion, "REQUEST");
    }

    /**
     * Logs an outgoing response.
     *
     * Creates a formatted log entry for a response being sent back to the client.
     *
     * @param response The response payload or content
     */
    public void logResponse(String response) {
        String timestamp = LocalDateTime.now().format(TIMESTAMP_FORMATTER);
        String formattedLog = formatLogEntry("Response sent", "N/A", "N/A", "N/A", timestamp);
        mongoLogger.log(formattedLog, null, response, "N/A", "N/A", "RESPONSE");
    }

    /**
     * Formats a log entry into a consistent JSON-like string.
     *
     * Creates a standardized log entry with action, query, device details,
     * and timestamp. Handles null inputs by replacing them with "N/A".
     *
     * @param action Description of the log action (e.g., "Request received")
     * @param query The query associated with the log entry
     * @param deviceModel The device model
     * @param osVersion The operating system version
     * @param timestamp Formatted timestamp string
     * @return Formatted log entry as a JSON-like string
     */
    private String formatLogEntry(String action, String query, String deviceModel, String osVersion, String timestamp) {
        return String.format(
                "{ \"action\": \"%s\", \"query\": \"%s\", \"deviceModel\": \"%s\", \"osVersion\": \"%s\", \"timestamp\": \"%s\" }",
                action,
                query != null ? query : "N/A",
                deviceModel != null ? deviceModel : "N/A",
                osVersion != null ? osVersion : "N/A",
                timestamp
        );
    }
}