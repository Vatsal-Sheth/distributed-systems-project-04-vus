package ds.bookapi;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class MongoLogFormatter {

    private final MongoLogger mongoLogger;

    private static final DateTimeFormatter TIMESTAMP_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS");

    // Constructor to initialize MongoLogger instance
    public MongoLogFormatter(MongoLogger mongoLogger) {
        this.mongoLogger = mongoLogger;
    }

    // Logs a request with query, device model, and OS version
    public void logRequest(String query, String deviceModel, String osVersion) {
        String timestamp = LocalDateTime.now().format(TIMESTAMP_FORMATTER);
        String formattedLog = formatLogEntry("Request received", query, deviceModel, osVersion, timestamp);
        mongoLogger.log(formattedLog, query, null, deviceModel, osVersion, "REQUEST");
    }

    // Logs a response with the response payload
    public void logResponse(String response) {
        String timestamp = LocalDateTime.now().format(TIMESTAMP_FORMATTER);
        String formattedLog = formatLogEntry("Response sent", "N/A", "N/A", "N/A", timestamp);
        mongoLogger.log(formattedLog, null, response, "N/A", "N/A", "RESPONSE");
    }

    // Formats a log entry
    private String formatLogEntry(String action, String query, String deviceModel, String osVersion, String timestamp) {
        return String.format(
                "{ \"action\": \"%s\", \"query\": \"%s\", \"deviceModel\": \"%s\", \"osVersion\": \"%s\", \"timestamp\": \"%s\" }",
                action,
                query != null ? query : "N/A",
                deviceModel != null ? deviceModel : "N/A",
                osVersion != null ? osVersion : "N/A",
                timestamp
        );
    }
}
