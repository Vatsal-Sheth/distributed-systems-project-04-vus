package ds.bookapi;

import com.mongodb.client.*;
import org.bson.Document;
import java.util.*;
import java.util.stream.Collectors;

public class MongoLogger {

    private MongoClient mongoClient;
    private MongoCollection<Document> logCollection;

    // Constructor
    public MongoLogger() {
        String uri = "mongodb+srv://vus:mNe86sPUKD4Ud8yb@cluster0.xh0eo.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0";
        mongoClient = MongoClients.create(uri);
        MongoDatabase database = mongoClient.getDatabase("BookServiceLogs");
        this.logCollection = database.getCollection("logs");
    }

    // Log method
    public void log(String message, String requestDetails, String responseDetails, String deviceModel, String deviceOS, String status) {
        Document log = new Document("message", message)
                .append("requestDetails", requestDetails)
                .append("responseDetails", responseDetails)
                .append("deviceModel", deviceModel)
                .append("deviceOS", deviceOS)
                .append("status", status)
                .append("timestamp", System.currentTimeMillis())
                .append("latency", new Random().nextInt(500)); // Example latency, replace with real value
        logCollection.insertOne(log);
    }

    // Get latest logs
    public List<String> getLatestLogs(int limit) {
        FindIterable<Document> results = logCollection.find()
                .sort(new Document("timestamp", -1))
                .limit(limit);

        List<String> logs = new ArrayList<>();
        for (Document doc : results) {
            logs.add(doc.toJson());
        }
        return logs;
    }

    // Get total requests count
    public int getTotalRequestCount() {
        return (int) logCollection.countDocuments();
    }

    // Get average latency
    public double getAverageLatency() {
        AggregateIterable<Document> result = logCollection.aggregate(
                Arrays.asList(
                        new Document("$group", new Document("_id", null)
                                .append("avgLatency", new Document("$avg", "$responseTime")))
                )
        );

        Document first = result.first();
        return (first != null && first.getDouble("avgLatency") != null)
                ? first.getDouble("avgLatency") : 0.0;
    }

    // Get top queries
    public Map<String, Integer> getTopQueries(int limit) {
        Map<String, Integer> topQueries = new LinkedHashMap<>();
        AggregateIterable<Document> result = logCollection.aggregate(
                Arrays.asList(
                        new Document("$group", new Document("_id", "$query")
                                .append("count", new Document("$sum", 1))),
                        new Document("$sort", new Document("count", -1)),
                        new Document("$limit", limit)
                )
        );

        for (Document doc : result) {
            topQueries.put(doc.getString("_id"), doc.getInteger("count"));
        }
        return topQueries;
    }

    // Close connection
    public void close() {
        if (mongoClient != null) {
            mongoClient.close();
        }
    }
    public void logDetailed(String message, String requestDetails, String responseDetails, String deviceModel, String deviceOS, String status) {
        Document log = new Document("message", message)
                .append("requestDetails", requestDetails)
                .append("responseDetails", responseDetails)
                .append("deviceModel", deviceModel)
                .append("deviceOS", deviceOS)
                .append("status", status)
                .append("timestamp", System.currentTimeMillis());
        logCollection.insertOne(log);
    }

}
