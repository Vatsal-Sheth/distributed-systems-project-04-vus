/**@author Vatsal Sheth
 * vus
 */
package ds.bookapi;

import com.mongodb.client.*;
import org.bson.Document;
import java.util.*;
import java.util.stream.Collectors;

/**
 * Manages logging operations for the Book Service using MongoDB.
 *
 * This class provides methods to log service interactions, retrieve log analytics,
 * and manage MongoDB connection for logging purposes.
 *
 */
public class MongoLogger {

    /**
     * MongoDB client for establishing database connection.
     */
    private MongoClient mongoClient;

    /**
     * MongoDB collection for storing log entries.
     */
    private MongoCollection<Document> logCollection;

    /**
     * Constructs a new MongoLogger and establishes a connection to MongoDB.
     *
     * Connects to the specified MongoDB Atlas cluster and initializes
     * the logs collection in the BookServiceLogs database.
     */
    public MongoLogger() {
        String uri = "mongodb+srv://vus:mNe86sPUKD4Ud8yb@cluster0.xh0eo.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0";
        mongoClient = MongoClients.create(uri);
        MongoDatabase database = mongoClient.getDatabase("BookServiceLogs");
        this.logCollection = database.getCollection("logs");
    }

    /**
     * Logs a service interaction with comprehensive device and request details.
     *
     * Creates a log entry in MongoDB with timestamp, request details,
     * device information, and a simulated latency.
     *
     * @param message Descriptive message about the log entry
     * @param requestDetails Details of the incoming request
     * @param responseDetails Details of the service response
     * @param deviceModel Model of the device making the request
     * @param deviceOS Operating system of the device
     * @param status Status of the request (e.g., success, failure)
     */
    public void log(String message, String requestDetails, String responseDetails, String deviceModel, String deviceOS, String status) {
        Document log = new Document("message", message)
                .append("requestDetails", requestDetails)
                .append("responseDetails", responseDetails)
                .append("deviceModel", deviceModel)
                .append("deviceOS", deviceOS)
                .append("status", status)
                .append("timestamp", System.currentTimeMillis())
                .append("latency", new Random().nextInt(500)); // Example latency, replace with real value
        logCollection.insertOne(log);
    }

    /**
     * Retrieves the most recent log entries.
     *
     * @param limit Maximum number of log entries to retrieve
     * @return List of log entries in JSON format, sorted by most recent timestamp
     */
    public List<String> getLatestLogs(int limit) {
        FindIterable<Document> results = logCollection.find()
                .sort(new Document("timestamp", -1))
                .limit(limit);

        List<String> logs = new ArrayList<>();
        for (Document doc : results) {
            logs.add(doc.toJson());
        }
        return logs;
    }

    /**
     * Calculates the total number of log entries.
     *
     * @return Total count of log entries in the collection
     */
    public int getTotalRequestCount() {
        return (int) logCollection.countDocuments();
    }

    /**
     * Calculates the average response time of logged requests.
     *
     * @return Average latency of requests, or 0.0 if no latency data exists
     */
    public double getAverageLatency() {
        AggregateIterable<Document> result = logCollection.aggregate(
                Arrays.asList(
                        new Document("$group", new Document("_id", null)
                                .append("avgLatency", new Document("$avg", "$responseTime")))
                )
        );

        Document first = result.first();
        return (first != null && first.getDouble("avgLatency") != null)
                ? first.getDouble("avgLatency") : 0.0;
    }

    /**
     * Retrieves the most frequent queries.
     *
     * @param limit Maximum number of top queries to retrieve
     * @return Map of queries and their occurrence count, sorted by frequency
     */
    public Map<String, Integer> getTopQueries(int limit) {
        Map<String, Integer> topQueries = new LinkedHashMap<>();
        AggregateIterable<Document> result = logCollection.aggregate(
                Arrays.asList(
                        new Document("$group", new Document("_id", "$query")
                                .append("count", new Document("$sum", 1))),
                        new Document("$sort", new Document("count", -1)),
                        new Document("$limit", limit)
                )
        );

        for (Document doc : result) {
            topQueries.put(doc.getString("_id"), doc.getInteger("count"));
        }
        return topQueries;
    }

    /**
     * Closes the MongoDB client connection.
     *
     * Ensures proper resource cleanup when logging is complete.
     */
    public void close() {
        if (mongoClient != null) {
            mongoClient.close();
        }
    }

    /**
     * Logs a service interaction with detailed information.
     *
     * Similar to {@link #log(String, String, String, String, String, String)},
     * but without the simulated latency.
     *
     * @param message Descriptive message about the log entry
     * @param requestDetails Details of the incoming request
     * @param responseDetails Details of the service response
     * @param deviceModel Model of the device making the request
     * @param deviceOS Operating system of the device
     * @param status Status of the request (e.g., success, failure)
     */
    public void logDetailed(String message, String requestDetails, String responseDetails, String deviceModel, String deviceOS, String status) {
        Document log = new Document("message", message)
                .append("requestDetails", requestDetails)
                .append("responseDetails", responseDetails)
                .append("deviceModel", deviceModel)
                .append("deviceOS", deviceOS)
                .append("status", status)
                .append("timestamp", System.currentTimeMillis());
        logCollection.insertOne(log);
    }
}