/**@author Vatsal Sheth
 * vus
 */
package ds.bookapi;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;

/**
 * Servlet for receiving and processing log entries via HTTP POST requests.
 *
 * This servlet accepts JSON-formatted log data, extracts relevant information,
 * and persists the log entries using MongoLogger.
 */
@WebServlet("/MonoLogger")
public class LogReceiverServlet extends HttpServlet {

    /**
     * The MongoLogger instance used to store log entries in the database.
     */
    private MongoLogger mongoLogger;

    /**
     * Initializes the servlet by creating a MongoLogger instance.
     *
     * This method is called by the servlet container when the servlet is first loaded.
     *
     * @throws ServletException if an error occurs during initialization
     */
    @Override
    public void init() throws ServletException {
        mongoLogger = new MongoLogger();
    }

    /**
     * Handles incoming POST requests containing log data.
     *
     * Reads the request body, parses the JSON log data, and logs the entry
     * using MongoLogger. Supports flexible JSON input with optional fields.
     *
     * @param req the HttpServletRequest object containing the log data
     * @param resp the HttpServletResponse object for sending the response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs during request processing
     */
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        StringBuilder requestBody = new StringBuilder();
        try (BufferedReader reader = req.getReader()) {
            String line;
            while ((line = reader.readLine()) != null) {
                requestBody.append(line);
            }
        }

        try {
            JSONObject logData = new JSONObject(requestBody.toString());
            String message = logData.getString("message");
            String requestDetails = logData.optString("requestDetails", "N/A");
            String responseDetails = logData.optString("responseDetails", "N/A");
            String deviceModel = logData.optString("deviceModel", "Unknown");
            String deviceOS = logData.optString("deviceOS", "Unknown");
            String status = logData.optString("status", "N/A");

            mongoLogger.logDetailed(message, requestDetails, responseDetails, deviceModel, deviceOS, status);
            resp.setStatus(HttpServletResponse.SC_OK);
        } catch (Exception e) {
            e.printStackTrace();
            resp.setStatus(HttpServletResponse.SC_BAD_REQUEST);
        }
    }

    /**
     * Closes the MongoDB connection when the servlet is being destroyed.
     *
     * This method is called by the servlet container when the servlet is about to
     * be removed from service, ensuring proper resource cleanup.
     */
    @Override
    public void destroy() {
        mongoLogger.close();
    }
}