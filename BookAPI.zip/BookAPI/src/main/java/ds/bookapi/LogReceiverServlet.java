package ds.bookapi;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
@WebServlet("/MonoLogger")
public class LogReceiverServlet extends HttpServlet {

    private MongoLogger mongoLogger;

    @Override
    public void init() throws ServletException {
        mongoLogger = new MongoLogger();
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        StringBuilder requestBody = new StringBuilder();
        try (BufferedReader reader = req.getReader()) {
            String line;
            while ((line = reader.readLine()) != null) {
                requestBody.append(line);
            }
        }

        try {
            JSONObject logData = new JSONObject(requestBody.toString());
            String message = logData.getString("message");
            String requestDetails = logData.optString("requestDetails", "N/A");
            String responseDetails = logData.optString("responseDetails", "N/A");
            String deviceModel = logData.optString("deviceModel", "Unknown");
            String deviceOS = logData.optString("deviceOS", "Unknown");
            String status = logData.optString("status", "N/A");

            mongoLogger.logDetailed(message, requestDetails, responseDetails, deviceModel, deviceOS, status);
            resp.setStatus(HttpServletResponse.SC_OK);
        } catch (Exception e) {
            e.printStackTrace();
            resp.setStatus(HttpServletResponse.SC_BAD_REQUEST);
        }
    }

    @Override
    public void destroy() {
        mongoLogger.close();
    }
}
