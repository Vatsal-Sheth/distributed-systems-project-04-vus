package ds.bookapi;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.URL;

@WebServlet("/fetchBooks")
public class FetchBooksServlet extends HttpServlet {
    private MongoLogger mongoLogger;
    private MongoLogFormatter mongoLogFormatter;
    @Override
    public void init() throws ServletException {
        mongoLogger = new MongoLogger(); // Create MongoLogger instance
        mongoLogFormatter = new MongoLogFormatter(mongoLogger); // Pass MongoLogger to MongoLogFormatter
    }
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        String query = req.getParameter("query");
        if (query == null || query.isEmpty()) {
            resp.sendError(HttpServletResponse.SC_BAD_REQUEST, "Missing query parameter");
            return;
        }

        mongoLogFormatter.logRequest(query, req.getHeader("Device-Model"), req.getHeader("OS-Version"));

        String apiUrl = "https://openlibrary.org/search.json?title=" + query.replace(" ", "+");
        try {
            HttpURLConnection connection = (HttpURLConnection) new URL(apiUrl).openConnection();
            connection.setRequestMethod("GET");

            BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            StringBuilder response = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                response.append(line);
            }

            mongoLogFormatter.logResponse(response.toString());

            resp.setContentType("application/json");
            PrintWriter writer = resp.getWriter();
            writer.write(response.toString());
        } catch (Exception e) {
            e.printStackTrace();
            resp.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Failed to fetch book data");
        }
    }
}
