/**
 Vatsal Sheth
 vus
 **/
package ds.edu.cmu;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import androidx.appcompat.widget.Toolbar;
import androidx.navigation.NavController;
import androidx.navigation.fragment.NavHostFragment;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

/**
 * The class serves as the entry point for the application.
 * It sets up the navigation architecture, including the NavHostFragment,
 * NavController, and AppBarConfiguration, and integrates the navigation functionality
 */
public class MainActivity extends AppCompatActivity {

    /**
     * Called when the activity is created. This method initializes the navigation
     * architecture components and sets up the toolbar.
     * @param savedInstanceState the saved instance state
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Set up the toolbar
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        // Get the NavController from the NavHostFragment
        NavHostFragment navHostFragment =
                (NavHostFragment) getSupportFragmentManager().findFragmentById(R.id.nav_host_fragment);
        if (navHostFragment != null) {
            NavController navController = navHostFragment.getNavController();

            // Set up the ActionBar with NavController
            AppBarConfiguration appBarConfiguration =
                    new AppBarConfiguration.Builder(navController.getGraph()).build();
            NavigationUI.setupActionBarWithNavController(this, navController, appBarConfiguration);
        } else {
            // Throw an exception if NavHostFragment is missing
            throw new IllegalStateException("NavHostFragment is null");
        }
    }

    /**
     * Handles the navigation up action. This method is called when the user
     * interacts with the Up button in the toolbar.
     * @return true if navigation was handled successfully, false otherwise
     */
    @Override
    public boolean onSupportNavigateUp() {
        NavHostFragment navHostFragment =
                (NavHostFragment) getSupportFragmentManager().findFragmentById(R.id.nav_host_fragment);
        if (navHostFragment != null) {
            NavController navController = navHostFragment.getNavController();
            // Attempt to navigate and if not it fall back to the default behavior
            return navController.navigateUp() || super.onSupportNavigateUp();
        }
        return super.onSupportNavigateUp(); // Default behavior if no NavController is found
    }
}