/**
 Vatsal Sheth
 vus
 **/
package ds.edu.cmu;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

/**
 * The below class extends RecyclerView.Adapter to display a list of books
 * in a RecyclerView. It handles the creation, binding, and management of ViewHolder
 * objects for each book item.
 */
public class BookAdapter extends RecyclerView.Adapter<BookAdapter.BookViewHolder> {

    private List<Book> bookList;

    /**
     * Constructs a new BookAdapter with the specified list of books.
     * @param bookList the list of Book objects to be displayed
     */
    public BookAdapter(List<Book> bookList) {
        this.bookList = bookList;
    }

    /**
     * Inflates the item layout and creates a new instance.
     * @param parent the parent `ViewGroup` into which the new view will be added
     * @param viewType the view type of the new view
     * @return a new instance
     */
    @NonNull
    @Override
    public BookViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_book, parent, false);
        return new BookViewHolder(view);
    }

    /**
     * Binds data from a Book object to the views in the BookViewHolder.
     * @param holder the BookViewHolder instance containing the views
     * @param position the position of the Book object in the list
     */
    @Override
    public void onBindViewHolder(@NonNull BookViewHolder holder, int position) {
        Book book = bookList.get(position);
        holder.textBookTitle.setText(book.getTitle());
        holder.textBookAuthor.setText(book.getAuthor());
    }

    /**
     * Returns the total number of items.
     * @return the size of the book list
     */
    @Override
    public int getItemCount() {
        return bookList.size();
    }

    /**
     * This class holds references to the views that display
     * individual book details in the RecyclerView.
     */
    public static class BookViewHolder extends RecyclerView.ViewHolder {
        TextView textBookTitle, textBookAuthor;

        /**
         * Constructs a new BookViewHolder.
         * @param itemView the root view of the item layout
         */
        public BookViewHolder(@NonNull View itemView) {
            super(itemView);
            textBookTitle = itemView.findViewById(R.id.textBookTitle);
            textBookAuthor = itemView.findViewById(R.id.textBookAuthor);
        }
    }
}
