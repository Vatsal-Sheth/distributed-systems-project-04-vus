/**
Vatsal Sheth
vus
 **/
package ds.edu.cmu;

import android.os.Build;
import android.os.Handler;
import android.os.Looper;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class BookApiService {
    /**
     * This class provides asynchronous methods for fetching book data from our webservice.
     * It supports querying books by title, retrieving detailed book facts, and finding workId using specific titles.
     * This class utilizes a thread pool and a UI handler for background execution and UI updates.
     */
    public interface BookApiCallback<T> {
        void onBooksFetched(T result);
    }

    private static final ExecutorService executorService = Executors.newFixedThreadPool(4);
    private static final Handler uiHandler = new Handler(Looper.getMainLooper());
    private static final String LOGGING_API_URL = "https://obscure-goldfish-vr7766jgq75cw576-8080.app.github.dev/";

    private static void sendLog(String message, String requestDetails, String responseDetails, String status) {
        executorService.execute(() -> {
            try {
                JSONObject logJson = new JSONObject();
                logJson.put("message", message);
                logJson.put("deviceModel", Build.MODEL);
                logJson.put("deviceOS", Build.VERSION.RELEASE);
                logJson.put("requestDetails", requestDetails);
                logJson.put("responseDetails", responseDetails);
                logJson.put("status", status);
                logJson.put("timestamp", System.currentTimeMillis());

                URL url = new URL(LOGGING_API_URL);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("POST");
                connection.setRequestProperty("Content-Type", "application/json");
                connection.setDoOutput(true);

                try (OutputStream os = connection.getOutputStream()) {
                    os.write(logJson.toString().getBytes());
                    os.flush();
                }

                connection.getResponseCode(); // Trigger the request
                connection.disconnect();
            } catch (Exception e) {
                e.printStackTrace(); // Log failure in sending logs
            }
        });
    }
    /**
     * Fetches books based on the specified query and returns the results via the callback.
     * @param query    the search query (book title)
     * @param callback the callback to handle the fetched books
     */
    public static void fetchBooks(String query, BookApiCallback<List<Book>> callback) {
        long startTime = System.currentTimeMillis();
        executorService.execute(() -> {
            String apiUrl = "https://openlibrary.org/search.json?title=" + query.replace(" ", "+");
            try {
                HttpURLConnection connection = (HttpURLConnection) new URL(apiUrl).openConnection();
                connection.setRequestMethod("GET");

                BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                StringBuilder response = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    response.append(line);
                }
                reader.close();
                JSONObject jsonResponse = new JSONObject(response.toString());
                JSONArray docsArray = jsonResponse.getJSONArray("docs");

                List<Book> books = new ArrayList<>();
                for (int i = 0; i < docsArray.length(); i++) {
                    JSONObject doc = docsArray.getJSONObject(i);
                    String title = doc.optString("title", "Unknown Title");
                    String author = doc.has("author_name") ? doc.getJSONArray("author_name").getString(0) : "Unknown Author";
                    String coverUrl = doc.has("cover_i") ? "https://covers.openlibrary.org/b/id/" + doc.getInt("cover_i") + "-L.jpg" : "";

                    books.add(new Book(title, author, coverUrl, ""));
                }
                // Callback with books
                uiHandler.post(() -> callback.onBooksFetched(books));
                sendLog(
                        "Fetched books",
                        apiUrl,
                        response.toString(),
                        "SUCCESS"
                );

            } catch (Exception e) {
                e.printStackTrace();
                uiHandler.post(() -> callback.onBooksFetched(new ArrayList<>()));
            }
        });
    }

    /**
     * Fetches detailed facts for a book using its `workId`, title, and
     * author, and returns the result via the callback.
     * @param workId the work ID of the book
     * @param bookTitle the title of the book
     * @param bookAuthor the author of the book
     * @param callback the callback to handle the fetched book details
     */
    public static void fetchBookFacts(String workId, String bookTitle, String bookAuthor, BookApiCallback<Book> callback) {
        executorService.execute(() -> {
            try {
                // Fetch book details using workId
                String workUrl = "https://openlibrary.org" + workId + ".json";
                JSONObject workResponse = getJsonResponse(workUrl);

                if (workResponse == null) {
                    uiHandler.post(() -> callback.onBooksFetched(null));
                    return;
                }

                // Extract basic book information
                String title = workResponse.optString("title", bookTitle);
                String description = workResponse.optString("description", "No Description Available");
                String publishDate = workResponse.optString("publish_date", "Unknown Year");
                int pageCount = workResponse.optInt("number_of_pages", 0);

                // Search for additional information using the book title
                String searchUrl = "https://openlibrary.org/search.json?title=" + title.replace(" ", "+");
                JSONObject searchResponse = getJsonResponse(searchUrl);

                String coverUrl = "";
                String fetchedAuthor = bookAuthor;

                if (searchResponse != null) {
                    JSONArray docsArray = searchResponse.optJSONArray("docs");

                    if (docsArray != null) {
                        for (int i = 0; i < docsArray.length(); i++) {
                            JSONObject doc = docsArray.getJSONObject(i);
                            String fetchedTitle = doc.optString("title", "");
                            String fetchedAuthorName = doc.has("author_name") ? doc.getJSONArray("author_name").getString(0) : "";

                            if (fetchedTitle.equalsIgnoreCase(title) && fetchedAuthorName.equalsIgnoreCase(bookAuthor)) {
                                coverUrl = doc.has("cover_i")
                                        ? "https://covers.openlibrary.org/b/id/" + doc.getInt("cover_i") + "-L.jpg"
                                        : "";
                                fetchedAuthor = fetchedAuthorName;
                                break;
                            }
                        }
                    }
                }

                // Create and populate the Book object
                Book bookDetails = new Book(title, fetchedAuthor, coverUrl, description);
                bookDetails.setPublishDate(publishDate);
                bookDetails.setPageCount(pageCount);

                // Pass the result to the callback
                uiHandler.post(() -> callback.onBooksFetched(bookDetails));
                sendLog(
                        "Book Details",
                        title,
                        bookDetails.toString(),
                        "SUCCESS"
                );

            } catch (Exception e) {
                e.printStackTrace();
                uiHandler.post(() -> callback.onBooksFetched(null));
            }
        });
    }


    /**
     * Helper method to perform HTTP GET requests and return the JSON response.
     * @param url the URL to fetch the response from
     * @return a JSONObject containing the response data
     */
    private static JSONObject getJsonResponse(String url) {
        try {
            HttpURLConnection connection = (HttpURLConnection) new URL(url).openConnection();
            connection.setRequestMethod("GET");

            try (BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()))) {
                StringBuilder response = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    response.append(line);
                }
                return new JSONObject(response.toString());
            }
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    /**
     * Fetches the workId for a book based on its title and passes the result via the callback.
     * @param title the title of the book
     * @param listener the callback to handle the fetched `workId`
     */
    public static void fetchWorkIdByTitle(String title, OnWorkIdFetchedListener listener) {
        executorService.execute(() -> {
            String baseUrl = "https://openlibrary.org/search.json?title=";
            try {
                URL url = new URL(baseUrl + title.replace(" ", "+"));
                HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
                urlConnection.setRequestMethod("GET");

                InputStream inputStream = urlConnection.getInputStream();
                BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
                StringBuilder response = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    response.append(line);
                }
                urlConnection.disconnect();

                JSONObject jsonResponse = new JSONObject(response.toString());
                JSONArray docsArray = jsonResponse.getJSONArray("docs");
                if (docsArray.length() > 0) {
                    JSONObject firstDoc = docsArray.getJSONObject(0);
                    String workId = firstDoc.optString("key"); // Get the `workId`
                    uiHandler.post(() -> listener.onWorkIdFetched(workId));
                } else {
                    uiHandler.post(() -> listener.onWorkIdFetched(null));
                }
            } catch (Exception e) {
                e.printStackTrace();
                uiHandler.post(() -> listener.onWorkIdFetched(null));
            }
        });
    }

    /**
     * Callback interface for fetching work IDs.
     */
    public interface OnWorkIdFetchedListener {
        void onWorkIdFetched(String workId);
    }

}
