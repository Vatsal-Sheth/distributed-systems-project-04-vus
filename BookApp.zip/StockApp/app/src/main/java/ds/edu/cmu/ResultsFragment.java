/**
 Vatsal Sheth
 vus
 **/
package ds.edu.cmu;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.ScrollView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * The class displays a list of book results based on the search query.
 * It retrieves book data passed via arguments, populates the ListView, and handles user
 * interactions to navigate to the DetailsFragment with the selected book's details.
 */
public class ResultsFragment extends Fragment {

    private ListView listView;
    private List<Book> books;

    /**
     * Inflates the layout for the fragment.
     * @param inflater the LayoutInflater used to inflate the layout
     * @param container the parent container
     * @param savedInstanceState the saved instance state if it is there
     * @return the inflated view
     */
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_results, container, false);
    }

    /**
     * Called after the view is created. This method initializes the UI components, processes
     * the book data passed as arguments, and sets up ListView with book titles.
     * @param view the root view of the fragment
     * @param savedInstanceState the saved instance state, if any
     */
    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // Initialize UI components
        ProgressBar loadingSpinner = view.findViewById(R.id.loadingSpinner);
        ScrollView contentLayout = view.findViewById(R.id.contentLayout);
        listView = view.findViewById(R.id.listViewBooks);

        // Retrieve arguments passed to the fragment
        if (getArguments() != null) {
            // Parse the JSON string to a list of Book objects
            String booksJson = getArguments().getString("booksJson");
            loadingSpinner.setVisibility(View.VISIBLE);
            contentLayout.setVisibility(View.GONE);
            if (booksJson != null) {
                Gson gson = new Gson();
                Type listType = new TypeToken<List<Book>>() {}.getType();
                books = gson.fromJson(booksJson, listType);

                // Create a list of book titles with authors for display
                List<String> bookTitles = books.stream()
                        .map(book -> book.getTitle() + " by " + book.getAuthor())
                        .collect(Collectors.toList());

                // Set up the ListView adapter
                ArrayAdapter<String> adapter = new ArrayAdapter<>(requireContext(),
                        android.R.layout.simple_list_item_1, bookTitles);
                listView.setAdapter(adapter);

                // Update UI to show content
                loadingSpinner.setVisibility(View.GONE);
                contentLayout.setVisibility(View.VISIBLE);

                // Handle item clicks in the ListView
                listView.setOnItemClickListener((parent, view1, position, id) -> {
                    Book selectedBook = books.get(position);

                    // Fetch workId via a secondary API call using the book title
                    BookApiService.fetchWorkIdByTitle(selectedBook.getTitle(), workId -> {
                        if (workId != null) {
                            // Pass the workId to the details fragment
                            Bundle bundle = new Bundle();
                            bundle.putString("workId", workId);
                            bundle.putString("bookTitle", selectedBook.getTitle());
                            bundle.putString("authorName", selectedBook.getAuthor());
                            Navigation.findNavController(view1).navigate(R.id.action_ResultsFragment_to_DetailsFragment, bundle);
                        } else {
                            // Handle error if workId is not found
                            System.out.println("Work ID not found for: " + selectedBook.getTitle());
                        }
                        // Restore the UI state
                        loadingSpinner.setVisibility(View.GONE);
                        contentLayout.setVisibility(View.VISIBLE);
                    });
                });
            }
        }
    }
}
