package ds.edu.cmu;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import com.squareup.picasso.Picasso;

/**
 * This class displays detailed information about a selected book.
 * It retrieves the book details using the workId passed as an argument and populates
 * the UI with title, author, description, publish date, page count, and cover image.
 */
public class DetailsFragment extends Fragment {

    private String bookTitle;
    private String bookAuthor;

    /**
     * Inflates the layout for the fragment.
     * @param inflater the LayoutInflater used to inflate the layout
     * @param container the parent container
     * @param savedInstanceState the saved instance state, if any
     * @return the inflated view
     */
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_details, container, false);
    }

    /**
     * Called after the view is created. This method initializes the UI components,
     * retrieves arguments, fetches book details, and populates the UI.
     * @param view the root view of the fragment
     * @param savedInstanceState if there are any then it saves the instance state
     */

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // Set up the action bar to display the back button
        if (getActivity() instanceof AppCompatActivity) {
            AppCompatActivity activity = (AppCompatActivity) getActivity();
            if (activity.getSupportActionBar() != null) {
                activity.getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            }
        }
        ProgressBar loadingSpinner = view.findViewById(R.id.loadingSpinner);
        ScrollView contentLayout = view.findViewById(R.id.contentLayout);

        // Retrieve arguments passed to the fragment
        if (getArguments() != null) {
            String workId = getArguments().getString("workId", "");
            String bookTitle = getArguments().getString("bookTitle", "Unknown Title");
            String authorName = getArguments().getString("authorName", "Unknown Author");

            // Initialize UI components
            TextView titleTextView = view.findViewById(R.id.bookTitle);
            TextView authorTextView = view.findViewById(R.id.bookAuthor);
            TextView descriptionTextView = view.findViewById(R.id.bookDescription);
            TextView publishDateTextView = view.findViewById(R.id.bookPublishDate);
            TextView pageCountTextView = view.findViewById(R.id.bookPageCount);
            ImageView coverImageView = view.findViewById(R.id.bookCover);

            // Show loading spinner and hide content layout
            loadingSpinner.setVisibility(View.VISIBLE);
            contentLayout.setVisibility(View.GONE);

            // Fetch book details using the API
            BookApiService.fetchBookFacts(workId, bookTitle, authorName, book -> {
                if (book != null) {
                    // Populate UI with fetched book details
                    titleTextView.setText(book.getTitle());
                    authorTextView.setText(book.getAuthor());
                    descriptionTextView.setText(book.getDescription());
                    publishDateTextView.setText(book.getPublishDate());
                    pageCountTextView.setText(String.valueOf(book.getPageCount()));
                    Picasso.get().load(book.getCoverUrl()).into(coverImageView);
                } else {
                    // Display a fallback message if details are unavailable
                    descriptionTextView.setText("Additional details not available.");
                }

                // Hide loading spinner and show content layout
                loadingSpinner.setVisibility(View.GONE);
                contentLayout.setVisibility(View.VISIBLE);
            });
        }
    }
}
