/**
 Vatsal Sheth
 vus
 **/
package ds.edu.cmu;

/**
 * The below class represents a book entity with its basic attributes
 * such as title, author, cover URL, description, publish date, and page count.
 * It provides getter and setter methods for interacting with these attributes.
 */
public class Book {
    private String title;
    private String author;
    private String coverUrl;
    private String description;
    private String publishDate;
    private int pageCount;

    /**
     * Constructs a new object with the specified title, author,
     * cover URL, and description. The publishDate and pageCount fields
     * can be set later using their respective setters.
     * @param title the title of the book
     * @param author the author of the book
     * @param coverUrl the URL of the book's cover image
     * @param description a brief description or summary of the book
     */
    public Book(String title, String author, String coverUrl, String description) {
        this.title = title;
        this.author = author;
        this.coverUrl = coverUrl;
        this.description = description;
    }

    public String getTitle() {
        return title;
    }

    public String getAuthor() {
        return author;
    }

    public String getCoverUrl() {
        return coverUrl;
    }

    public String getDescription() {
        return description;
    }

    public String getPublishDate() {
        return publishDate;
    }

    public void setPublishDate(String publishDate) {
        this.publishDate = publishDate;
    }

    public int getPageCount() {
        return pageCount;
    }

    public void setPageCount(int pageCount) {
        this.pageCount = pageCount;
    }
}
