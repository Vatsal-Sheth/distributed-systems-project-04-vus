/**
 Vatsal Sheth
 vus
 **/
package ds.edu.cmu;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;

import com.google.gson.Gson;

import java.util.List;

/**
 * This class provides a user interface for searching books.
 * It allows users to enter a search query and initiates a search through the
 * BookApiService. The results are passed to the ResultsFragment.
 */

public class SearchFragment extends Fragment {

    private EditText searchEditText;
    private Button searchButton;

    /**
     * Inflates the layout for the fragment and initializes the search UI components.
     * @param inflater the LayoutInflater used to inflate the layout
     * @param container the parent container
     * @param savedInstanceState the saved instance state, if any
     * @return the inflated view
     */
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_search, container, false);

        // Initialize UI components
        searchEditText = view.findViewById(R.id.editTextSearch);
        searchButton = view.findViewById(R.id.buttonSearch);

        // Set up the click listener for the search button
        searchButton.setOnClickListener(v -> performSearch());

        return view;
    }

    /**
     * Validates the search query and initiates the book search using BookApiService
     * If the query is valid, results are fetched and passed to the ResultsFragment
     */
    private void performSearch() {
        String query = searchEditText.getText().toString().trim();

        if (!query.isEmpty()) {
            // Call the Book API service to fetch books
            BookApiService.fetchBooks(query, books -> {
                if (books != null && !books.isEmpty()) {
                    navigateToResultsFragment(books); // Navigate to the ResultsFragment if books are found
                } else {
                    // Show an error message if no books are found
                    searchEditText.setError("No books found for the given query.");
                }
            });
        } else {
            // Show an error message if the search query is empty
            searchEditText.setError("Please enter a search term.");
        }
    }

    /**
     * Navigates to the ResultsFragment with the list of books as JSON data.
     * @param books the list of books fetched from the API
     */
    private void navigateToResultsFragment(List<Book> books) {
        // Convert the list of books to JSON for passing to the ResultsFragment
        Gson gson = new Gson();
        String booksJson = gson.toJson(books);

        // Create a Bundle to hold the JSON data
        Bundle bundle = new Bundle();
        bundle.putString("booksJson", booksJson);

        // Navigate to the ResultsFragment with the Bundle
        Navigation.findNavController(requireView())
                .navigate(R.id.action_SearchFragment_to_ResultsFragment, bundle);
    }

}
