/**
Vatsal Sheth
vus
 **/
package ds.edu.cmu;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.squareup.picasso.Picasso;


/**
 * The below class is responsible for displaying the details of a book.
 * It retrieves data from the intent passed by the previous activity and displays
 * the book title, author, and cover image in the UI.
 */
public class BookDetailsActivity extends AppCompatActivity {

    /**
     * Called when the activity is created. This method initializes the UI and
     * @param savedInstanceState the saved instance state, if any
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_book_details);

        // Initialize views
        TextView titleView = findViewById(R.id.bookTitle);
        TextView authorView = findViewById(R.id.bookAuthor);
        ImageView coverView = findViewById(R.id.bookCover);

        // Retrieve book data from intent
        String bookTitle = getIntent().getStringExtra("bookTitle");
        String bookAuthor = getIntent().getStringExtra("bookAuthor");
        String bookCoverUrl = getIntent().getStringExtra("bookCoverUrl");

        // Set the retrieved data to views
        titleView.setText(bookTitle);
        authorView.setText(bookAuthor);
        if (bookCoverUrl != null && !bookCoverUrl.isEmpty()) {
            Picasso.get().load(bookCoverUrl).into(coverView);
        } else {
            // Set a placeholder image if the book cover URL is null or empty
            coverView.setImageResource(R.drawable.placeholder); // Use a placeholder image
        }
    }
}
